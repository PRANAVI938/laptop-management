# Laptop-shop
This is my Java spring training project

The idea is to create an information system for selling laptops with the roles: Administrator, Seller, Buyer.

#Buyer's functions:
authorization, product selection from the catalog, order, order tracking, change information about yourself, leave a review, add to the list of favorite products.

#Seller's functions:
Add products and accessories to the database, complete the order + buyer functions.

#Administrator's fucntions:
All of the above and what he will write himself :)
