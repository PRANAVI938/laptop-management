package com.laptopssale.Entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.List;


public enum VideoMemory {
    GDDR3, GDDR5, GDDR6;
}
