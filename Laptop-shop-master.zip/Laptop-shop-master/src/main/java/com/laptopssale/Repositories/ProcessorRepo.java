package com.laptopssale.Repositories;

import com.laptopssale.Entities.Processor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessorRepo extends JpaRepository<Processor, Long> {
}
